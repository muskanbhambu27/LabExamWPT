// routes/addArticle.js

const express = require('express');
const router = express.Router();
const Article = require('../models/article');

// POST /api/articles - Create a new article
router.post('/', async (req, res) => {
  try {
    const { name, category, creatorName } = req.body;
    const article = new Article({ name, category, creatorName });
    await article.save();
    res.status(201).json(article);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
// ---------------------create close----------------------------//


// routes/updateArticle.js

const express = require('express');
const router = express.Router();
const Article = require('../models/article');

// PATCH /api/articles/:id - Update an article
router.patch('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, category, creatorName } = req.body;
    const updatedArticle = await Article.findByIdAndUpdate(id, { name, category, creatorName }, { new: true });
    if (!updatedArticle) {
      return res.status(404).json({ message: 'Article not found' });
    }
    res.json(updatedArticle);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;

//-----------------------update close--------------------------------

// routes/readArticles.js

const express = require('express');
const Router = express.Router();
const Article = require('../models/article');

// GET /api/articles - Get all articles
router.get('/', async (req, res) => {
  try {
    const articles = await Article.find();
    res.json(articles);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;

//-----------------------------read close-------------------------




