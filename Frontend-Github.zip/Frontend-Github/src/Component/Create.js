import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Create() {
  const [name, setName] = useState('');
  const [category, setcategory] = useState('');
  const [dateCreated, setPassword] = useState('');
  const [creatorName, setcreatorName] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:9595/user/add', {
      name,category,dateCreated,creatorName })
    .then(response => { console.log(response.data); navigate('/'); })
    .catch(error => {console.error(error);});
  };

  return (
    <div className="container">
      <h2>Create User</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Name</label>
          <input type="text" className="form-control" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="form-group">
          <label>category</label>
          <input type="text" className="form-control" value={category} onChange={(e) => setcategory(e.target.value)}/>
        </div>
        <div className="form-group">
          <label>CreatedDate</label>
          <input type="dateCreated" className="form-control" value={dateCreated} onChange={(e) => setPassword(e.target.value)}/>
        </div>
        <div className="form-group">
          <label>creatorName</label>
          <input type="creatorName" className="form-control" value={creatorName} onChange={(e) => setcreatorName(e.target.value)}/>
        </div>
        <button type="submit" className="btn btn-primary mt-2">Submit</button>
      </form>
    </div>
  );
}
