import React from 'react'
import { Link } from "react-router-dom";
export default function Home() {
  return (
    <>
      <div class="card">
  <div class="card-body">
    <h5 class="card-title">mesuem</h5>
    <h6 class="card-subtitle mb-2 text-body-secondary">Articles</h6>
    <p class="card-text">all the artcile in the mesuem is unique</p>
    <Link to="/create" class="card-link">add articles</Link>
    <Link to="/read" class="card-link">all artciles</Link>
  </div>
</div>
    </>
  );
}
