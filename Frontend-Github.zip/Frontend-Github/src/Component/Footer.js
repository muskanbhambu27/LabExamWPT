import React from 'react'

export default function Footer() {
  return (
    <>
      <div className="footer text-center">
        <h5>Lab-Exam</h5>
      </div>
    </>
  )
}
